DELETE
FROM [dbo].[ServiceClientAccess]

DELETE
FROM [dbo].[ServiceClient]
